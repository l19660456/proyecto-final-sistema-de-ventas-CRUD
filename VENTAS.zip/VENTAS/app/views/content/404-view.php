<div class="main-container">
    <section class="hero-body">
	  	<div class="hero-body">
	  		<p class="has-text-centered has-text-white pb-3">
	            <i class="fas fa-satellite-dish fa-5x"></i>
	        </p>
		    <p class="title has-text-white">Error 404</p>
		    <p class="subtitle has-text-white">Pagina no encontrada</p>
	  	</div>
	</section>
</div>