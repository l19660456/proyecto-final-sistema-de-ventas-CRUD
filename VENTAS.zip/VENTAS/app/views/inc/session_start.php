<?php
    session_name(APP_SESSION_NAME);
    session_start();