<script>
    function print_ticket(url){
        window.open(url,'Imprimir ticket','width=400,height=720,top=0,left=100,menubar=NO,toolbar=YES');
    }
    function print_invoice(url){
        window.open(url,'Imprimir factura','width=820,height=720,top=0,left=100,menubar=NO,toolbar=YES');
    }
</script>